/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylib;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Date;
/**
 *
 * @author ASUS
 */
public class MyLib {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Membuat objek AnggotaPerpustakaan
        AnggotaPerpustakaan anggota1 = new AnggotaPerpustakaan("Jaemin Na", "12345678", "Jl. Besar 123, Kota Tangerang");
        AnggotaPerpustakaan anggota2 = new AnggotaPerpustakaan("Kusuma Yudha", "87654321", "Jl. Kecil 456, Kota Jakarta");
        AnggotaPerpustakaan anggota3 = new AnggotaPerpustakaan("Layla Shim", "55555555", "Jl. Indah 789, Kota Bandung");
        AnggotaPerpustakaan anggota4 = new AnggotaPerpustakaan("Markonah", "11112222", "Jl. Cerah 101, Kota Surabaya");
        AnggotaPerpustakaan anggota5 = new AnggotaPerpustakaan("Naura Wijaya", "99998888", "Jl. Asri 555, Kota Medan");

        // Membuat objek Buku
        Buku buku1 = new Buku("Harry Potter dan Menjelawat Fantasi", "J.K. Rowling", "1234567890", true);
        Buku buku2 = new Buku("Lord of the Rings", "J.R.R. Tolkien", "0987654321", true);
        Buku buku3 = new Buku("To Kill a Mockingbird", "Harper Lee", "1111222233", false);
        Buku buku4 = new Buku("1984", "George Orwell", "4444555566", true);
        Buku buku5 = new Buku("Pride and Prejudice", "Jane Austen", "7777888899", false);

        // Membuat objek TransaksiPeminjaman dan TransaksiPengembalian
        TransaksiPeminjaman transaksiPeminjaman1 = new TransaksiPeminjaman(new Date(), LocalTime.now(), Duration.ofHours(1), buku1);
        TransaksiPengembalian transaksiPengembalian1 = new TransaksiPengembalian(new Date(), LocalTime.now(), buku1);

        TransaksiPeminjaman transaksiPeminjaman2 = new TransaksiPeminjaman(new Date(), LocalTime.now(), Duration.ofDays(2), buku2);
        TransaksiPengembalian transaksiPengembalian2 = new TransaksiPengembalian(new Date(), LocalTime.now(), buku2);

        TransaksiPeminjaman transaksiPeminjaman3 = new TransaksiPeminjaman(new Date(), LocalTime.now(), Duration.ofDays(7), buku3);
        TransaksiPengembalian transaksiPengembalian3 = new TransaksiPengembalian(new Date(), LocalTime.now(), buku3);

        TransaksiPeminjaman transaksiPeminjaman4 = new TransaksiPeminjaman(new Date(), LocalTime.now(), Duration.ofDays(14), buku4);
        TransaksiPengembalian transaksiPengembalian4 = new TransaksiPengembalian(new Date(), LocalTime.now(), buku4);

        TransaksiPeminjaman transaksiPeminjaman5 = new TransaksiPeminjaman(new Date(), LocalTime.now(), Duration.ofDays(30), buku5);
        TransaksiPengembalian transaksiPengembalian5 = new TransaksiPengembalian(new Date(), LocalTime.now(), buku5);
        
        // Menampilkan seluruh data anggota
        System.out.println("=== Seluruh Data Anggota ===");
        anggota1.tampilkanDataAnggota();
        anggota2.tampilkanDataAnggota();
        anggota3.tampilkanDataAnggota();
        anggota4.tampilkanDataAnggota();
        anggota5.tampilkanDataAnggota();

        // Menampilkan seluruh data buku
        System.out.println("=== Seluruh Data Buku ===");
        buku1.tampilkanDataBuku();
        buku2.tampilkanDataBuku();
        buku3.tampilkanDataBuku();
        buku4.tampilkanDataBuku();
        buku5.tampilkanDataBuku();

        // Menampilkan seluruh data transaksi peminjaman
        System.out.println("=== Seluruh Data Transaksi Peminjaman ===");
        transaksiPeminjaman1.tampilkanDataTransaksiPeminjaman();
        transaksiPeminjaman2.tampilkanDataTransaksiPeminjaman();
        transaksiPeminjaman3.tampilkanDataTransaksiPeminjaman();
        transaksiPeminjaman4.tampilkanDataTransaksiPeminjaman();
        transaksiPeminjaman5.tampilkanDataTransaksiPeminjaman();

        // Menampilkan seluruh data transaksi pengembalian
        System.out.println("=== Seluruh Data Transaksi Pengembalian ===");
        transaksiPengembalian1.tampilkanDataTransaksiPengembalian();
        transaksiPengembalian2.tampilkanDataTransaksiPengembalian();
        transaksiPengembalian3.tampilkanDataTransaksiPengembalian();
        transaksiPengembalian4.tampilkanDataTransaksiPengembalian();
        transaksiPengembalian5.tampilkanDataTransaksiPengembalian();
    }
}