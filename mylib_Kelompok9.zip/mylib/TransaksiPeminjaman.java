/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylib;

 import java.time.Duration;
import java.time.LocalTime;
import java.util.Date;

/**
 *
 * @author ASUS
 */
//public class TransaksiPeminjaman {
 import java.time.Duration;
import java.time.LocalTime;
import java.util.Date;

public class TransaksiPeminjaman {
    private Date tanggal;
    private LocalTime waktu;
    private Duration durasi;
    private Buku bukuDipinjam;

    public TransaksiPeminjaman(Date tanggal, LocalTime waktu, Duration durasi, Buku bukuDipinjam) {
        this.tanggal = tanggal;
        this.waktu = waktu;
        this.durasi = durasi;
        this.bukuDipinjam = bukuDipinjam;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public LocalTime getWaktu() {
        return waktu;
    }

    public void setWaktu(LocalTime waktu) {
        this.waktu = waktu;
    }

    public Duration getDurasi() {
        return durasi;
    }

    public void setDurasi(Duration durasi) {
        this.durasi = durasi;
    }

    public Buku getBukuDipinjam() {
        return bukuDipinjam;
    }

    public void setBukuDipinjam(Buku bukuDipinjam) {
        this.bukuDipinjam = bukuDipinjam;
    }
    
    public void tampilkanDataTransaksiPeminjaman() {
        System.out.println("Data Transaksi Peminjaman:");
        System.out.println("Tanggal: " + tanggal +
                " | Waktu: " + waktu +
                " | Durasi: " + durasi +
                " | Buku: " + bukuDipinjam.getJudul());
        System.out.println();
    }
}

   
    
