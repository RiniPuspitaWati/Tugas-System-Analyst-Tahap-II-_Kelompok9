/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylib;

import java.util.Date;
import java.time.LocalTime;
import java.time.Duration;
import java.util.List;
/**
 *
 * @author ASUS
 */
//public class Admin {
public class Admin {
    public void kelolaAnggota(List<AnggotaPerpustakaan> anggotaList, AnggotaPerpustakaan anggota, boolean tambah) {
        if (tambah) {
            anggotaList.add(anggota);
            System.out.println("Anggota ditambahkan.");
        } else {
            anggotaList.remove(anggota);
            System.out.println("Anggota dihapus.");
        }
    }

    public void kelolaBuku(List<Buku> bukuList, Buku buku, boolean tambah) {
        if (tambah) {
            bukuList.add(buku);
            System.out.println("Buku ditambahkan.");
        } else {
            for (Buku existingBuku : bukuList) {
                if (existingBuku.getNomorISBN().equals(buku.getNomorISBN())) {
                    existingBuku.setJudul(buku.getJudul());
                    existingBuku.setPengarang(buku.getPengarang());
                    existingBuku.setStatusKetersediaan(buku.isStatusKetersediaan());
                    System.out.println("Buku diubah.");
                    return;
                }
            }
            System.out.println("Buku tidak ditemukan.");
        }
    }

    public void kelolaTransaksiPeminjaman(List<TransaksiPeminjaman> transaksiList, TransaksiPeminjaman transaksi) {
        transaksiList.add(transaksi);
        System.out.println("Transaksi peminjaman dicatat.");
    }

    public void kelolaTransaksiPengembalian(List<TransaksiPengembalian> transaksiList, TransaksiPengembalian transaksi) {
        transaksiList.add(transaksi);
        System.out.println("Transaksi pengembalian dicatat.");
    }
}   
