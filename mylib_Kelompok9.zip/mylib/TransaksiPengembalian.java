/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylib;

import java.time.LocalTime;
import java.util.Date;
/**
 *
 * @author ASUS
 */
//public class TransaksiPengembalian {
import java.time.LocalTime;
import java.util.Date;

public class TransaksiPengembalian {
    private Date tanggal;
    private LocalTime waktu;
    private Buku bukuDikembalikan;

    public TransaksiPengembalian(Date tanggal, LocalTime waktu, Buku bukuDikembalikan) {
        this.tanggal = tanggal;
        this.waktu = waktu;
        this.bukuDikembalikan = bukuDikembalikan;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public LocalTime getWaktu() {
        return waktu;
    }

    public void setWaktu(LocalTime waktu) {
        this.waktu = waktu;
    }

    public Buku getBukuDikembalikan() {
        return bukuDikembalikan;
    }

    public void setBukuDikembalikan(Buku bukuDikembalikan) {
        this.bukuDikembalikan = bukuDikembalikan;
    }
    
    public void tampilkanDataTransaksiPengembalian() {
        System.out.println("Data Transaksi Pengembalian:");
        System.out.println("Tanggal: " + tanggal +
                " | Waktu: " + waktu +
                " | Buku: " + bukuDikembalikan.getJudul());
        System.out.println();
    }

   
}