/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylib;

import java.time.LocalTime;
import java.util.Date;

/**
 *
 * @author ASUS
 */
//public class Notifikasi {
import java.time.LocalTime;
import java.util.Date;

public class Notifikasi {
    private String pesan;
    private Date tanggal;
    private LocalTime waktu;

    public Notifikasi(String pesan, Date tanggal, LocalTime waktu) {
        this.pesan = pesan;
        this.tanggal = tanggal;
        this.waktu = waktu;
    }

    public String getPesan() {
        return pesan;
    }

    public void setPesan(String pesan) {
        this.pesan = pesan;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public LocalTime getWaktu() {
        return waktu;
    }

    public void setWaktu(LocalTime waktu) {
        this.waktu = waktu;
    }
    
}