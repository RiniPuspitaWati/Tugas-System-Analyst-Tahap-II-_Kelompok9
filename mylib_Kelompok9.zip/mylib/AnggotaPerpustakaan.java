/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylib;

import java.util.Date;
import java.time.LocalTime;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author ASUS
 */
//public class AnggotaPerpustakaan {
public class AnggotaPerpustakaan {
    private String nama;
    private String nomorAnggota;
    private String alamat;
    private List<TransaksiPeminjaman> riwayatPeminjaman;

    public AnggotaPerpustakaan(String nama, String nomorAnggota, String alamat) {
        this.nama = nama;
        this.nomorAnggota = nomorAnggota;
        this.alamat = alamat;
        this.riwayatPeminjaman = new ArrayList<>();
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNomorAnggota() {
        return nomorAnggota;
    }

    public void setNomorAnggota(String nomorAnggota) {
        this.nomorAnggota = nomorAnggota;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public List<TransaksiPeminjaman> getRiwayatPeminjaman() {
        return riwayatPeminjaman;
    }

    public void setRiwayatPeminjaman(List<TransaksiPeminjaman> riwayatPeminjaman) {
        this.riwayatPeminjaman = riwayatPeminjaman;
    }
    
    public TransaksiPeminjaman pinjamBuku(Buku buku) {
        // Implementasi peminjaman buku
        TransaksiPeminjaman transaksi = new TransaksiPeminjaman(new Date(), LocalTime.now(), Duration.ofDays(7), buku);
        riwayatPeminjaman.add(transaksi);
        return transaksi;
    }
    
    public void terimaNotifikasi(Notifikasi notifikasi) {
        // Implementasi penerimaan notifikasi
        System.out.println("Menerima notifikasi: " + notifikasi.getPesan());
    }
    
    public void tampilkanDataAnggota() {
        System.out.println("Data Anggota:");
        System.out.println("Nama: " + nama);
        System.out.println("Nomor Anggota: " + nomorAnggota);
        System.out.println("Alamat: " + alamat);
        System.out.println("Riwayat Peminjaman:");
        for (TransaksiPeminjaman transaksi : riwayatPeminjaman) {
            System.out.println("   - Tanggal: " + transaksi.getTanggal() +
                    " | Waktu: " + transaksi.getWaktu() +
                    " | Durasi: " + transaksi.getDurasi() +
                    " | Buku: " + transaksi.getBukuDipinjam().getJudul());
        }
        System.out.println();
    }
}